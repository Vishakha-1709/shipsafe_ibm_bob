# Clean Sample Application

## Setup & Installation
```bash
pip install -r requirements.txt
```

## Usage
```bash
python app.py
```

## Tests
```bash
pytest tests/
```
