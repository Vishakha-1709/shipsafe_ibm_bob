def test_app_initialization():
    assert True
