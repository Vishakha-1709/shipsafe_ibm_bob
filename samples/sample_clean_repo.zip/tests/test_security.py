def test_security_environment_variables():
    import os
    assert os.getenv("APP_ENV", "production") == "production"
