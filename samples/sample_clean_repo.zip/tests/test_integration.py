def test_api_contract():
    assert 200 == 200
