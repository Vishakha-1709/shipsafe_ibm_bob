import os
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("API_KEY")

def run():
    print("Service initialized securely with IBM Bob workflows.")

if __name__ == "__main__":
    run()
