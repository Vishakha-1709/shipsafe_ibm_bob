import os
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("API_KEY")

def run():
    print("Service initialized securely.")

if __name__ == "__main__":
    run()
