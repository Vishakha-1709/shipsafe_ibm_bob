import os
import requests

# 🚨 Critical Security Violation: Hardcoded API key & DB connection
API_KEY = "sk-live-99238472918347102938471928347192"
DB_CONNECTION = "postgres://admin:superSecretPass123!@localhost:5432/production_db"

def predict(input_data):
    headers = {"Authorization": f"Bearer {API_KEY}"}
    response = requests.post("https://api.internal-service.com/v1/predict", json=input_data, headers=headers)
    return response.json()

if __name__ == "__main__":
    print("Running predictor service...")
